import pandas as pd
from sqlalchemy import create_engine, text

def main():
    engine = create_engine("sqlite:///database/fake_jobs.db")

    try:
        preds = pd.read_sql(
            "SELECT y_true, y_pred_logreg, y_pred_svm, y_pred_rf FROM model_predictions",
            engine,
        )
        print("\nEvaluation from model_predictions")
        for name in ["y_pred_logreg", "y_pred_svm", "y_pred_rf"]:
            cm = pd.crosstab(
                preds["y_true"],
                preds[name],
                rownames=["Actual (0=legit, 1=fraud)"],
                colnames=[f"Predicted ({name})"],
                dropna=False,
            ).reindex(index=[0, 1], columns=[0, 1], fill_value=0)

            tn = cm.loc[0, 0]
            fp = cm.loc[0, 1]
            fn = cm.loc[1, 0]
            tp = cm.loc[1, 1]

            print(f"\nConfusion matrix for {name} (rows=actual, cols=predicted):")
            print(cm)
            print(
                f"  - True negatives (legit predicted legit): {tn}\n"
                f"  - False positives (legit predicted fraud): {fp}\n"
                f"  - False negatives (fraud predicted legit): {fn}\n"
                f"  - True positives (fraud predicted fraud): {tp}"
            )
    except Exception as exc:
        print(f"\nCould not compute evaluation from model_predictions: {exc}")


if __name__ == "__main__":
    main()
