import pandas as pd
from sqlalchemy import create_engine
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    classification_report,
    accuracy_score,
    precision_recall_fscore_support,
    confusion_matrix,
)
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import LinearSVC
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler
from scipy.sparse import hstack, csr_matrix
from datetime import datetime


def train_models(db_path="database/fake_jobs.db"):
    #load the database
    engine = create_engine(f"sqlite:///{db_path}")
    print(f"Connected to database: {db_path}")

    df = pd.read_sql("SELECT * FROM job_postings_encoded", engine)
    print(f"Loaded encoded dataset: {df.shape}")

    #seperate features & labels
    X = df.drop(columns=["fraudulent"])
    y = df["fraudulent"]

    X_num = X.select_dtypes(include=["number", "bool"]).copy()
    for col in X_num.columns:
        if X_num[col].dtype == bool:
            X_num[col] = X_num[col].astype(int)

    text_series = df["description"].fillna("").astype(str)

    #80/20 train/test split
    X_train_num, X_test_num, X_train_text, X_test_text, y_train, y_test = train_test_split(
        X_num,
        text_series,
        y,
        test_size=0.2,
        random_state=42,
        stratify=y
    )
    print("Completed train/test split")

    # vectorize text w/ TF-IDF
    tfidf = TfidfVectorizer(max_features=15000, ngram_range=(1, 2))
    X_train_tfidf = tfidf.fit_transform(X_train_text)
    X_test_tfidf = tfidf.transform(X_test_text)
    print(f"TF-IDF shapes -> train: {X_train_tfidf.shape}, test: {X_test_tfidf.shape}")

    #combine numeric and text features
    scaler = StandardScaler(with_mean=False)
    X_train_num_scaled = scaler.fit_transform(csr_matrix(X_train_num.values))
    X_test_num_scaled = scaler.transform(csr_matrix(X_test_num.values))

    X_train_combined = hstack([X_train_num_scaled, X_train_tfidf])
    X_test_combined = hstack([X_test_num_scaled, X_test_tfidf])

    def eval_and_log(model_name, y_true, y_pred):
        prec, rec, f1, _ = precision_recall_fscore_support(
            y_true, y_pred, average="binary", pos_label=1, zero_division=0
        )
        acc = accuracy_score(y_true, y_pred)
        tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
        print(f"\n===== {model_name} Report =====")
        print(classification_report(y_true, y_pred))
        print("Accuracy:", acc)
        return {
            "model_name": model_name,
            "run_timestamp": datetime.utcnow().isoformat(),
            "accuracy": acc,
            "precision": prec,
            "recall": rec,
            "f1": f1,
            "tn": tn,
            "fp": fp,
            "fn": fn,
            "tp": tp,
        }

    metrics_records = []

    #logistic regression training
    print("\nTraining Logistic Regression")
    logreg = LogisticRegression(
        solver="lbfgs",
        penalty="l2",
        C=2.0,
        max_iter=30000,
        class_weight="balanced",
        n_jobs=-1
    )
    logreg.fit(X_train_combined, y_train)

    print(f"Logistic Regression iterations: {logreg.n_iter_.max()}")

    y_pred_logreg = logreg.predict(X_test_combined)
    metrics_records.append(eval_and_log("logistic_regression", y_test, y_pred_logreg))

    #linear SVM training
    print("\nTraining Linear SVM")
    svm = LinearSVC(class_weight="balanced")
    svm.fit(X_train_combined, y_train)
    y_pred_svm = svm.predict(X_test_combined)
    metrics_records.append(eval_and_log("linear_svm", y_test, y_pred_svm))

    #random forest training
    print("\nTraining Random Forestt")
    rf = RandomForestClassifier(
        n_estimators=250,
        max_depth=None,
        class_weight="balanced",
        random_state=42,
        n_jobs=-1
    )
    rf.fit(X_train_num, y_train)

    y_pred_rf = rf.predict(X_test_num)
    metrics_records.append(eval_and_log("random_forest", y_test, y_pred_rf))

    results_df = pd.DataFrame({
        "y_true": y_test.values,
        "y_pred_logreg": y_pred_logreg,
        "y_pred_svm": y_pred_svm,
        "y_pred_rf": y_pred_rf
    })

    results_df.to_sql(
        "model_predictions",
        engine,
        if_exists="replace",
        index=False
    )

    #save to database
    metrics_df = pd.DataFrame(metrics_records)
    metrics_df.to_sql(
        "model_versions",
        engine,
        if_exists="append",
        index=False
    )

    print("Saved predictions to table: model_predictions")
    print("Appended metrics to table: model_versions")
    print("Training don.")

if __name__ == "__main__":
    train_models()

#this was so harddd help me