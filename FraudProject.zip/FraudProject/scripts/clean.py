import pandas as pd
from sqlalchemy import create_engine

def clean_raw_data(db_path: str = "database/fake_jobs.db"):
    #connect to database
    engine = create_engine(f"sqlite:///{db_path}")
    print(f"Connected to database: {db_path}")

    #load table
    df = pd.read_sql("SELECT * FROM job_postings_raw", engine)
    print(f"Loaded raw data: {df.shape}")

    # clean data
    df = df.dropna(subset=["description"])
    print(f"Dropped rows with missing descriptions: {df.shape}")

    #columns
    text_cols = [
        "title", "location", "department", "salary_range",
        "company_profile", "description", "requirements",
        "benefits", "employment_type", "required_experience",
        "required_education", "industry", "function"
    ]

    for col in text_cols:
        if col in df.columns:
            df[col] = df[col].fillna("").astype(str).str.lower().str.strip()

    print("Normalized text columns.")

    categorical_fill = [
        "employment_type",
        "required_experience",
        "required_education",
        "industry",
        "function",
        "location",
        "salary_range"
    ]

    for col in categorical_fill:
        if col in df.columns:
            df[col] = df[col].replace("", "unknown")

    print(" Filled missing categorical fields with 'unknown'")

    before = df.shape[0]
    df = df.drop_duplicates(subset=["description"])
    after = df.shape[0]

    print(f"Removed {before - after} duplicate descriptions")

    df.to_sql(
        "job_postings_cleaned",
        engine,
        if_exists="replace",
        index=False
    )

    print(f"Saved cleaned table: job_postings_cleaned ({df.shape})")

if __name__ == "__main__":
    clean_raw_data()
