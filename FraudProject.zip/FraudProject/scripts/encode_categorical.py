import pandas as pd
from sqlalchemy import create_engine

def encode_categoricals(db_path: str = "database/fake_jobs.db"):
    #connect to database
    engine = create_engine(f"sqlite:///{db_path}")
    print(f"Connected to database: {db_path}")

    #load table
    df = pd.read_sql("SELECT * FROM job_postings_metadata", engine)
    print(f"Loaded metadata table: {df.shape}")

    #categories to encode
    categorical_cols = [
        "employment_type",
        "required_experience",
        "required_education",
        "industry",
        "function",
        "email_domain_type"
    ]

    #fix NaNs
    for col in categorical_cols:
        if col in df.columns:
            df[col] = df[col].fillna("unknown").astype(str)

    #numeric label
    if "fraudulent" in df.columns:
        df["fraudulent"] = df["fraudulent"].astype(int)

    #numeric metadata
    for col in ["has_email", "suspicious_keywords"]:
        if col in df.columns:
            df[col] = df[col].astype(int)

    print(f"One-hot encoding columns: {categorical_cols}")

    #encode
    df_encoded = pd.get_dummies(df, columns=categorical_cols, dummy_na=True)

    print(f"Encoding done, New shape: {df_encoded.shape}")

    #save to database
    df_encoded.to_sql(
        "job_postings_encoded",
        engine,
        if_exists="replace",
        index=False
    )

    print(f"Saved table: job_postings_encoded ({df_encoded.shape})")
    

if __name__ == "__main__":
    encode_categoricals()
