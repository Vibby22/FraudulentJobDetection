import os
import pandas as pd
from sqlalchemy import create_engine

def load_csv_to_sqlite(csv_path: str, db_path: str = "database/fake_jobs.db"):
    #path
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"CSV file not found: {csv_path}")

    print(f"Loading data from: {csv_path}")

    #read CSV
    df = pd.read_csv(csv_path)
    print(f"Loaded data with shape: {df.shape}")

    #make SQLite database
    engine = create_engine(f"sqlite:///{db_path}")
    print(f"Created SQLite database: {db_path}")

    #load into database
    df.to_sql(
        "job_postings_raw",
        engine,
        if_exists="replace",
        index=False
    )

    print("Wrote table: job_postings_raw")


if __name__ == "__main__":
    CSV_FILE = "data/fake_job_postings.csv"
    load_csv_to_sqlite(CSV_FILE)
