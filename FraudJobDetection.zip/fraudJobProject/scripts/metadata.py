import re
import pandas as pd
from sqlalchemy import create_engine

def count_words(text):
    #word counter
    if not isinstance(text, str) or text.strip() == "":
        return 0
    return len(text.split())


def contains_email(text):
    #returns 1 if text contains an email address
    if not isinstance(text, str):
        return 0
    pattern = r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+"
    return 1 if re.search(pattern, text) else 0


def email_domain_type(text):
    #return email type
    if not isinstance(text, str):
        return "none"

    match = re.search(r"@([A-Za-z0-9.-]+)", text)
    if not match:
        return "none"

    domain = match.group(1).lower()

    free_domains = {"gmail.com", "yahoo.com", "hotmail.com", "outlook.com", "aol.com"}

    if domain in free_domains:
        return "free"
    else:
        return "company"


def keyword_flag(text):
    #returns 1 if sus
    if not isinstance(text, str):
        return 0

    keywords = [
        "wire transfer",
        "western union",
        "urgent position",
        "no experience needed",
        "quick money",
        "investment",
        "data entry from home",
        "easy money",
        "make money fast",
        "scam",
        "crypto",
        "bitcoin"
    ]

    text_lower = text.lower()
    for kw in keywords:
        if kw in text_lower:
            return 1
    return 0

#digit counter
def count_digits(text):
    if not isinstance(text, str):
        return 0
    return sum(char.isdigit() for char in text)

def extract_metadata(db_path: str = "database/fake_jobs.db"):
    #connect to database
    engine = create_engine(f"sqlite:///{db_path}")
    print(f"Connected to database: {db_path}")

    #load from clean.py
    df = pd.read_sql("SELECT * FROM job_postings_cleaned", engine)
    print(f"Loaded cleaned data: {df.shape}")

    print("metadata features")

    df["desc_length"] = df["description"].apply(count_words)
    df["requirements_length"] = df["requirements"].apply(count_words)
    df["benefits_length"] = df["benefits"].apply(count_words)

    df["title_digit_count"] = df["title"].apply(count_digits)

    df["has_email"] = df["description"].apply(contains_email)
    df["email_domain_type"] = df["description"].apply(email_domain_type)

    df["suspicious_keywords"] = df["description"].apply(keyword_flag)

    print("Metadata extraction done")

    #save to database
    df.to_sql(
        "job_postings_metadata",
        engine,
        if_exists="replace",
        index=False
    )

    print(f"Saved table")

if __name__ == "__main__":
    extract_metadata()
