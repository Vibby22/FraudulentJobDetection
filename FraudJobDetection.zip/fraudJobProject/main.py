from scripts.load import load_csv_to_sqlite
from scripts.clean import clean_raw_data
from scripts.metadata import extract_metadata
from scripts.encode_categorical import encode_categoricals
from scripts.train_model import train_models

def run_step(name, fn, *args, **kwargs):
    print(f"\nStarting: {name}")
    fn(*args, **kwargs)
    print(f"finished: {name}")


def main():
    csv_path = "data/fake_job_postings.csv"
    db_path = "database/fake_jobs.db"

    run_step("Load Data", load_csv_to_sqlite, csv_path, db_path=db_path)
    run_step("Clean Data", clean_raw_data, db_path=db_path)
    run_step("Extract Metadata", extract_metadata, db_path=db_path)
    run_step("Encode Categoricals", encode_categoricals, db_path=db_path)
    run_step("Train Models", train_models, db_path=db_path)

    print("\nfinished")


if __name__ == "__main__":
    main()
